#include <iostream>
#include "Server.h"
using namespace std;

int main()
{
    ServerDemon demon;
    demon.RunDemon();
}
